package connectinfo

import (
	"context"
	"errors"
	"fmt"
	"net"
	"path"
	"strconv"
	"strings"

	"github.com/bedrock-tool/bedrocktool/utils/auth"
	"github.com/bedrock-tool/bedrocktool/utils/franchise/gatherings"
	"github.com/google/uuid"
	"github.com/sandertv/gophertunnel/minecraft/realms"
)

type ErrNotFound struct {
	Name string
}

func (e *ErrNotFound) Error() string {
	return fmt.Sprintf("%s not found", e.Name)
}

type ConnectInfo struct {
	Value   string
	Account *auth.Account

	gathering  *gatherings.Gathering
	realm      *realms.Realm
	experience *gatherings.FeaturedServer
}

func (c *ConnectInfo) getGathering(ctx context.Context, name string) (*gatherings.Gathering, error) {
	if c.gathering != nil && c.gathering.Title == name {
		return c.gathering, nil
	}
	gatheringsService, err := c.Account.Gatherings(ctx)
	if err != nil {
		return nil, err
	}
	mcToken, err := c.Account.MCToken(ctx)
	if err != nil {
		return nil, err
	}
	gatherings, err := gatheringsService.GetGatherings(ctx, mcToken)
	if err != nil {
		return nil, err
	}
	for _, gathering := range gatherings {
		title := strings.ToLower(gathering.Title)
		id := strings.ToLower(gathering.GatheringID)
		if strings.HasPrefix(title, name) || strings.HasPrefix(id, name) {
			return gathering, nil
		}
	}
	return nil, &ErrNotFound{Name: name}
}

func (c *ConnectInfo) getExperience(ctx context.Context, name string) (*gatherings.FeaturedServer, error) {
	if c.experience != nil {
		if c.experience.ExperienceId == name {
			return c.experience, nil
		}
		if strings.EqualFold(c.experience.Name, name) {
			return c.experience, nil
		}
	}
	gatherings, err := c.Account.Gatherings(ctx)
	if err != nil {
		return nil, err
	}
	mcToken, err := c.Account.MCToken(ctx)
	if err != nil {
		return nil, err
	}
	featuredServers, err := gatherings.GetFeaturedServers(ctx, mcToken)
	if err != nil {
		return nil, err
	}
	for _, experience := range featuredServers {
		if experience.ExperienceId == name || strings.EqualFold(experience.Name, name) {
			c.experience = &experience
			return c.experience, nil
		}
	}
	return nil, &ErrNotFound{Name: name}
}

func (c *ConnectInfo) getRealm(ctx context.Context, name string) (*realms.Realm, error) {
	name = strings.ToLower(name)
	if c.realm != nil && strings.EqualFold(c.realm.Name, name) || strconv.Itoa(c.realm.ID) == name {
		return c.realm, nil
	}
	realms, err := c.Account.Realms().Realms(ctx)
	if err != nil {
		return nil, err
	}
	for _, realm := range realms {
		lowerName := strings.ToLower(realm.Name)
		if strings.HasPrefix(lowerName, name) || strconv.Itoa(c.realm.ID) == name {
			return &realm, nil
		}
	}
	return nil, &ErrNotFound{Name: name}
}

func (c *ConnectInfo) Name(ctx context.Context) (string, error) {
	info, err := parseConnectInfo(c.Value)
	if err != nil {
		return "", nil
	}
	if info.netherNet != "" {
		return info.netherNet, nil
	}
	if info.serverAddress != "" {
		host, port, err := net.SplitHostPort(info.serverAddress)
		if err != nil {
			host = info.serverAddress
		} else if port != "19132" {
			host += "_" + port
		}

		return host, nil
	}
	if info.replayName != "" {
		return path.Base(info.replayName), nil
	}
	if info.realmName != "" {
		realm, err := c.getRealm(ctx, info.realmName)
		if err != nil {
			return "", err
		}
		return realm.Name, nil
	}
	if info.gatheringName != "" {
		gathering, err := c.getGathering(ctx, info.gatheringName)
		if err != nil {
			return "", err
		}
		return gathering.Title, nil
	}
	if info.experience != "" {
		exp, err := c.getExperience(ctx, info.experience)
		switch {
		case errors.Is(err, &ErrNotFound{}):
			return info.experience, nil
		case err != nil:
			return "", err
		default:
			return exp.Name, nil
		}
	}
	return "invalid", nil
}

func (c *ConnectInfo) Address(ctx context.Context) (string, error) {
	info, err := parseConnectInfo(c.Value)
	if err != nil {
		return "", err
	}
	if info.netherNet != "" {
		return "nethernet:" + info.netherNet, nil
	}
	if info.serverAddress != "" {
		return info.serverAddress, nil
	}
	if info.replayName != "" {
		return info.replayName, nil
	}
	if info.realmName != "" {
		realm, err := c.getRealm(ctx, info.realmName)
		if err != nil {
			return "", err
		}
		address, err := realm.Address(ctx)
		if err != nil {
			return "", err
		}
		return address.Address, nil
	}
	if info.gatheringName != "" {
		gathering, err := c.getGathering(ctx, info.gatheringName)
		if err != nil {
			return "", err
		}
		mcToken, err := c.Account.MCToken(ctx)
		if err != nil {
			return "", err
		}
		return gathering.Address(ctx, mcToken)
	}

	if info.experience != "" {
		expId, err := uuid.Parse(info.experience)
		if err != nil {
			experience, err := c.getExperience(ctx, info.experience)
			if err != nil {
				return "", err
			}
			expId, err = uuid.Parse(experience.ExperienceId)
			if err != nil {
				return "", err
			}
		}
		gatheringsService, err := c.Account.Gatherings(ctx)
		if err != nil {
			return "", err
		}
		mcToken, err := c.Account.MCToken(ctx)
		if err != nil {
			return "", err
		}
		address, err := gatheringsService.JoinExperience(ctx, mcToken, expId)
		if err != nil {
			return "", fmt.Errorf("JoinExperience: %w", err)
		}
		return address, nil
	}
	return "", errors.New("invalid address")
}

func (c *ConnectInfo) IsReplay() bool {
	return pcapRegex.MatchString(c.Value)
}

func (c *ConnectInfo) SetRealm(realm *realms.Realm) {
	c.Value = "realm:" + realm.Name
	c.realm = realm
}

func (c *ConnectInfo) SetGathering(gathering *gatherings.Gathering) {
	c.Value = "gathering:" + gathering.Title
	c.gathering = gathering
}

func (c *ConnectInfo) SetFeaturedServer(server *gatherings.FeaturedServer) {
	if server.ExperienceId != "" {
		c.Value = "experience:" + server.Name
		c.experience = server
	} else {
		c.Value = server.Address
	}
}

type parsedConnectInfo struct {
	gatheringName string
	realmName     string
	replayName    string
	experience    string
	serverAddress string
	netherNet     string
}

func parseConnectInfo(value string) (*parsedConnectInfo, error) {
	if gatheringRegex.MatchString(value) {
		p := regexGetParams(gatheringRegex, value)
		input := strings.ToLower(p["Title"])
		return &parsedConnectInfo{gatheringName: input}, nil
	}

	if experienceRegex.MatchString(value) {
		p := regexGetParams(experienceRegex, value)
		return &parsedConnectInfo{experience: p["ID"]}, nil
	}

	// realm
	if realmRegex.MatchString(value) {
		p := regexGetParams(realmRegex, value)
		input := strings.ToLower(p["Name"])
		return &parsedConnectInfo{realmName: input}, nil
	}

	// pcap replay
	if pcapRegex.MatchString(value) {
		p := regexGetParams(pcapRegex, value)
		input := p["Filename"]
		return &parsedConnectInfo{replayName: input}, nil
	}

	// nethernet id
	if strings.HasPrefix(value, "nethernet:") {
		id := strings.Split(value, ":")[1]
		_, err := uuid.Parse(id)
		if err != nil {
			return nil, fmt.Errorf("nethernet: %s", err)
		}
		return &parsedConnectInfo{netherNet: id}, nil
	}

	// normal server dns or ip
	serverAddress := value
	if len(strings.Split(serverAddress, ":")) == 1 {
		serverAddress += ":19132"
	}
	return &parsedConnectInfo{serverAddress: serverAddress}, nil
}
