package internal

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
)

const minecraftUserAgent = "libhttpclient/1.0.0.0"

type JsonResponseError struct {
	Status string
	Data   map[string]any
}

func (e JsonResponseError) Error() string {
	message, ok := e.Data["message"].(string)
	if ok {
		return e.Status + "\n" + message
	}
	return e.Status
}

func DoRequest[T any](ctx context.Context, client *http.Client, method, url string, payload any, extraHeaders func(*http.Request)) (*T, error) {
	var body io.Reader = nil
	if payload != nil {
		bodyData, err := json.Marshal(payload)
		if err != nil {
			return nil, err
		}
		body = bytes.NewReader(bodyData)
	}
	req, err := http.NewRequestWithContext(ctx, method, url, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "*/*")
	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	req.Header.Set("User-Agent", minecraftUserAgent)
	req.Header.Set("Accept-Language", "en-US,en;q=0.5")
	req.Header.Set("Cache-Control", "no-cache")
	if extraHeaders != nil {
		extraHeaders(req)
	}

	res, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()

	if res.StatusCode >= 400 {
		bodyResp, err := io.ReadAll(res.Body)
		if err != nil {
			return nil, err
		}
		var resp map[string]any
		err = json.Unmarshal(bodyResp, &resp)
		if err != nil {
			return nil, err
		}
		return nil, &JsonResponseError{
			Status: res.Status,
			Data:   resp,
		}
	}

	bodyResp, err := io.ReadAll(res.Body)
	if err != nil {
		return nil, err
	}

	var resp T
	err = json.Unmarshal(bodyResp, &resp)
	if err != nil {
		return nil, err
	}
	return &resp, nil
}
